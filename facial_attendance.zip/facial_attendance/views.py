from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

@login_required
def dashboard(request):
    if not request.user.face_verified:
        return redirect('verify_face_page')

    return render(request, 'attendance/dashboard.html', {'user': request.user})